<?php include '../../db.php'; ?>

<?php 
    $query = 'SELECT * FROM User';
    $message = mysqli_query($connection, $query);

    if(isset($_GET['action']) && isset($_GET['user_id'])){
        if ($_GET['action'] == 'block'){
            $user_id = $_GET['user_id'];
           
            
           # $reason = $_GET['reason'];
            
           # $query = "INSERT into Blocked VALUES ($user_id, $reason)"
            
           # $query = "UPDATE User SET status = 3 WHERE user_id= $user_id UNION INSERT INTO Blocked Values($user_id, $reason)";
            
            # $query = "DELETE from User WHERE user_id = $user_id";
            
            if(!mysqli_query($connection, $query)){
                die(mysqli_error($connection));
            }
            else {
                header("Location: index.php?success=User%20Removed");
            }
        }
    }
?>

<?php 
    $query = 'SELECT * FROM Medicine';
    $medicine = mysqli_query($connection, $query);

    if(isset($_GET['action']) && isset($_GET['med_id'])){
        if ($_GET['action'] == 'delete'){
            $med_id = $_GET['med_id'];
            
            $query = "DELETE from Medicines WHERE med_id = $med_id";
            
            if(!mysqli_query($connection, $query)){
                die(mysqli_error($connection));
            }
            else {
                header("Location: index.php?success=User%20Removed");
            }
        }
    }
?>

<?php 
    $query = 'SELECT * FROM Reviews';
    $reviews = mysqli_query($connection, $query);

    if(isset($_GET['action']) && isset($_GET['review_id'])){
        if ($_GET['action'] == 'delete'){
            $reivew_id = $_GET['review_id'];
            
            $query = "DELETE from Reviews WHERE review_id = $review_id";
            
            if(!mysqli_query($connection, $query)){
                die(mysqli_error($connection));
            }
            else {
                header("Location: index.php?success=Review%20Denied");
            }
        }
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Administrator Portal</title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container-fluid">
  
            <!--Top navigation bar-->
            <div class="nav">
                <nav class="navbar navbar-expand-lg ">
                   <a class="navbar-brand" href="#">Medication Leaflet System</a>
                   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                       <span class="navbar-toggler-icon"></span>
                   </button>
                   <div class="collapse navbar-collapse" id="navbarText">
                       <ul class="navbar-nav mr-auto">
                           <li class="nav-item">
                               <a class="nav-link" href="index.html">Dashboard <span class="sr-only">(current)</span></a>
                           </li>
                           <li class="nav-item">
                               <a class="nav-link" href="#">Settings</a>
                           </li>
                           <li class="nav-item">
                               <a class="nav-link" href="#">Help</a>
                           </li>
                       </ul>
                       <span class="navbar-text" id="adminName">Doe, John 012345</span>
                   </div>
                </nav>
            </div>
            
            <!--Side navigation bar-->
            <div class="side-nav">
                <div class="sidenav">
                    <a href="#" onclick="showOverview()">Overview</a>
                    <a href="#" onclick="showMed()">Manage Medicine</a>
                    <a href="#" onclick="showUser()">Manage Users</a>
                    <a href="#" onclick="showReviews()">Manage Reviews</a>
                    <a href="#">Confirm License</a>
                </div>
            </div>
            <div class="main">
                
                
                
                
                <!----Overview-->
                <div id="overview" id="hiddenOverview">
                    <!--Start table--->
                    <table class="table table-hover medTable hiddenOverview">
                        <thead>
                            <tr>
                                <th id="dateAlert">Date</th>
                                <th id="timeAlert">Time</th>
                                <th id="typeAlert">Type</th>
                                <th id="titleAlert">Title</th>
                                <th id="requstAlert">Requested By</th>
                            </tr>
                        </thead>
                             <tbody>
                          <tr>
                              
                              
                              
                              
                                    </table>
                      
                </div>
                
                <!-----Manage Users--->
                <div class="manageUsers hidden" id="hiddenUser">
                    <button id="add_user" type="button" class="button" ><i class="fas fa-plus"></i> Add User</button>
                    <table class="table table-hover">
                        <thead>
                          <tr>
                              <th scope="col">User Since</th>
                              <th scope="col">ID</th>
                              <th scope="col">Username</th>
                              <th scope="col">Status</th>
                              <th scope="col">Type</th>
                              <th colspan="2" scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                              <?php while($row = mysqli_fetch_assoc($message)) : ?>
                              <?php if ($row['type'] == 1){
                                    $type = "User";
                                } else if ($row['type'] == 2){
                                    $type = "Administrator";
                                } else if ($row['type'] == 3) {
                                    $type = "Data Entry";
                                } else {
                                    $type = "Invalid";
                                }
                              ?>
                               <?php if ($row['status'] == 1){
                                    $status = "Pending";
                                } else if ($row['status'] == 2){
                                    $status = "Active";
                                } else if ($row['status'] == 3) {
                                    $status = "Banned";
                                } else {
                                    $status = "Invalid";
                                }
                              ?>
                              <th scope="row"><?php echo $row['created'];?></th>
                              <td><?php echo $row['user_id'];?></td>
                              <td><?php echo $row['username'];?></td>
                              <td><?php echo $status;?></td>
                              <td><?php echo $type;?></td>
                              <td>
                                  <a href="#" id="block-button"><i class="far fa-edit" ></i>Edit</a>
                                  <a href="index.php?action=block&user_id=<?php echo $row['user_id'];?>"><i class="fas fa-trash-alt"></i> Block</a>    
                              </td>
                            </tr>
                        </tbody>
                        <?php endwhile; ?>
                                    </table>
                    
                </div>
                    
                    <!------Manage Medicine------>
                   
                <div class="manageMedicine hidden" id="hiddenMedicine">
                    <button id="add_med" type="button" class="button" onclick="showMedForm()" ><i class="fas fa-plus"></i> Add Medicine</button>
                    <table class="table table-hover">
                        <thead>
                          <tr>
                              <th scope="col">ID</th>
                              <th scope="col">Name</th>
                              <th scope="col">Generic Name</th>
                              <th scope="col">Status</th>
                              <th colspan="2" scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                              <?php while($row = mysqli_fetch_assoc($medicine)) : ?>
                              <td><?php echo $row['med_id'];?></td>
                              <td><?php echo $row['brand_name'];?></td>
                              <td><?php echo $row['gen_name'];?></td>
                              <td><?php echo $row['status'];?></td>
                              
                              <td>
                                  <a href="#"><i class="far fa-edit"></i>Edit</a>
                                  <a href="index.php?action=delete&med_id=<?php echo $row['user_id'];?>"><i class="fas fa-trash-alt"></i> Delete</a>    
                              </td>
                            </tr>
                        </tbody>
                        <?php endwhile; ?>
                                    </table>
                    
                </div>
                    
                     <!------Manage Reviews------>
                   
                <div class="manageReviews hidden" id="hiddenReviews">
                    <table class="table table-hover">
                        <thead>
                          <tr>
                              <th scope="col">Date</th>
                              <th scope="col">User</th>
                              <th scope="col">Medicine</th>
                              <th scope="col">Review</th>
                              <th scope="col">Rating</th>
                              <th colspan="2" scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                              <?php while($row = mysqli_fetch_assoc($reviews)) : ?>
                              <td><?php echo $row['review_time'];?></td>
                              <td><?php echo $row['username'];?></td>
                              <td><?php echo $row['med_id'];?></td>
                              <td><?php echo $row['review_txt'];?></td>
                              
                              <td>
                                  <a href="#"><i class="far fa-edit"></i>Approve</a>
                                  <a href="index.php?action=delete&review_id=<?php echo $row['review_id'];?>"><i class="fas fa-trash-alt"></i> Deny</a>    
                              </td>
                            </tr>
                        </tbody>
                        <?php endwhile; ?>
                                    </table>
                    
                </div>
                    
                    <!---------Add Medicine Form------->
                
                <div class="addmedicine_form hidden" id="add-med-form">
                    <div class="form-wrap">
                
                <form class="form-horizontal" role="form">
                    <fieldset>
                        <legend>Add Medicine</legend>
                        <div class="row">
                            <div class="col-xs-6 col-sm-6 col-md-8">
                                <div class="form-group">    
                                    <div class="form-line">
                                        <label for="name" class="control-label">Name of Medicine</label>
                                        <div class='input-group'>
                                            <input id="nameofMed" name="nameOfMedicine" type="text" class="form-control input-md" required="">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-6 col-sm-6 col-md-2">
                                <div class="form-group">    
                                    <div class="form-line">
                                        <label for="dosage" class="control-label">Dosage</label>
                                        <input id="dosageNum" name="dosage" type=number placeholder="milligrams" class="form-control input-md" required="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6 col-sm-6 col-md-8">
                                <div class="form-group">    
                                    <div class="form-line">
                                        <label for="RXNum" class="control-label">RX Number</label>
                                        <div class='input-group'>
                                            <input id="rxNum" name="rxNum" type="text" class="form-control input-md" placeholder="XXXXXXX-XXXXX" required="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-2">
                                <div class="form-group">    
                                    <div class="form-line">
                                        <label for="food" class="control-label">Taken With A Meal?</label>
                                        <select id="foodValidation" name="food" class="form-control">
                                            <option value="1">Select</option>
                                            <option value="1">Yes</option>
                                            <option value="2">No</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-10">
                                <div class="form-group">    
                                    <div class="form-line">
                                        <label for="name" class="control-label">Messages</label>
                                        <div class="input-group">
                                            <textarea class="form-control" id="messageForMed" name="message"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-default submit-btn addMeds">Submit</button>
                                        <button type="reset" class="btn btn-default reset-btn addMeds">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </form>
                </div>
            </div>
                    
                  
                        <div class="block-modal hidden">
                        <div class="block-modal-content">
                            <div class="close">X</div>
                            <form>
                                User: <?php echo $row['user_id'] ?>
                                Reason for block:<br>
                                <textarea name="block-reason" rows="5" cols="25"></textarea><br>
                                <input type="submit">
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
        <script type="text/javascript">
            var user = document.getElementById("hiddenUser");
            var med = document.getElementById("hiddenMedicine");
            var overview = document.getElementById("hiddenOverview");
            var review = document.getElementById("hiddenReviews");
            var medform = document.getElementById("add-med-form");
            
            document.getElementById('block-button').addEventListener('click', function() {
    document.querySelector('.block-modal').style.display = "flex";
});
            
            document.querySelector('.close').addEventListener('click', function(){
                document.querySelector('.block-modal').style.display = "none";
            });
            function showMed() {
                
                if (med.style.display === "none") {
                    med.style.display = "block";
                    user.style.display = "none";
                    overview.style.display = "none";
                    review.style.display = "none";
                    medform.style.display = "none";
                } else {
                med.style.display = "none";
                }
            }
            
            function showUser() {
            
                if (user.style.display === "none") {
                    user.style.display = "block";
                    med.style.display = "none";
                    overview.style.display = "none";
                    review.style.display = "none";
                    medform.style.display = "none";
                } else {
                user.style.display = "none";
                }
                
            }
            
            function showReviews() {
            
                if (review.style.display === "none") {
                    review.style.display = "block";
                    med.style.display = "none";
                    overview.style.display = "none";
                    user.style.display = "none";
                    medform.style.display = "none";
                } else {
                review.style.display = "none";
                }
                
            }
            
            function showOverview() {
                if (overview.style.display === "none") {
                    overview.style.display = "block";
                    med.style.display = "none";
                    user.style.display = "none";
                    review.style.display = "none";
                    medform.style.display = "none";
                } else {
                overview.style.display = "none";
                }
            }
            
            function showMedForm() {
                
                if (medform.style.display === "none") {
                    medform.style.display = "block";
                } else {
                medform.style.display = "none";
                }
            }
            
            
            
        </script>
            
    </body>
</html>