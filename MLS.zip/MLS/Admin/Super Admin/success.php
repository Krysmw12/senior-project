<?php include '../../db.php'; ?>

<?php
    if(!empty($_POST['userid'])) {
        
        $date = date('Y-m-d H:i:s');
        
        echo 'Added Data Entry User:\n';
        echo $_POST['userid'] . '\n';
        echo $_POST['username'];
        echo $_POST['firstname'];
        echo $_POST['lastname'];
        echo 'Created: ' . $date;
        
        $userid = mysqli_real_escape_string($connection, $_POST['userid']);
        $username = mysqli_real_escape_string($connection, $_POST['username']);
        $firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
        $lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
        $password = mysqli_real_escape_string($connection, $_POST['password']);
        
        
        $query = "INSERT into User(user_id, username, first_name, last_name, password, created, type, status, longitude, latitude) VALUES('$userid', '$username', '$firstname', '$lastname', '$password', '$date', '3', '1', '0.0', '0.0')";
        
        if(!mysqli_query($connection, $query)){
                die(mysqli_error($connection));
            }  else {
                header("Location: success.php?success=User%20Created");
            }
        
   }   else{
        header("Location: register.php?error=Please%20Fill%20All%20Fields");
   }
?>