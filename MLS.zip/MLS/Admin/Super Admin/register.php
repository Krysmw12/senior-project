<?php include '../../db.php'; ?>

<?php
    $query = "SELECT * from User";
$message = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>MLS | Data Entry Registration</title>
        <link rel="stylesheet" href="../style.css" type="text/css">
    </head>
    <body>
        <div class="container">
            <div class="main">
                <form method="POST" action="success.php">
                    User ID:<br>
                    <input onload="generateID()" type="number" name="userid" id="userid" required>
                    <input type="button" value="Generate User ID" name="gUID" onclick="generateID()">
                    <br>
                    First Name:<br>
                    <input type="text" name="firstname"><br>
                    Last Name:<br>
                    <input type="text" name="lastname"><br>
                    E-Mail:<br>
                    <input type="email" name="email" required><br>
                    Username:<br>
                    <input type="text" name="username" required><br>
                    Password:<br>
                    <input type="password" name="password" required><br>
                    <input type="reset" value="Reset Fields">
                    <input type="submit" value="Register">
                    
                </form>
            </div>
        </div>
        
        <script>
            var userID;
            
            function generateID() {
                var userID;
                
                userID = Math.floor((Math.random() * 99999) + 10000);
                
                document.getElementById('userid').value = userID;
            }
        </script>
    </body>
</html>