<?php

$connection = mysqli_connect('localhost', 'root', 'password', 'MLS Dummy');

//Test Connect
if(mysqli_connect_errno()){
    echo 'DB connection error: ' .mysqli_connect_error();
}