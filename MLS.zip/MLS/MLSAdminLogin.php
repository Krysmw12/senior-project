<?php include 'db.php'; ?>

<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTD-8">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css" type="text/css">
        
        <title>Medication Leaflet System</title>
    </head>
    <body>
        <div class="container login-html">
            
            <div class="page-header col-sm-4 login-wrap login-form">
                <img class= "logo" src="images/MLS-Logo.jpg" width="180" height="115" alt="Medication Leaflet System Logo">
                <h1>Medication Leaflet System</h1>
                <form method="POST" action="">
                    <div class="form-group login-forme">Username
                        <input type="text" class="form-control" name="user">
                    </div>
                    <div class="form-group" >
                        <label for="pw">Password</label>
                        <input type="password" class="form-control" name="pass">
                    </div>
                    <div>
                        <button type="submit" class ="btn btn-default button" id="register">Register</button>
                        <button type="submit" class ="btn btn-default button" id="login">Login</button>
                    </div>
                </form>
                
                </div>
            </div>
        
        <?php  
            if(isset($_POST["submit"])){  

            if(!empty($_POST['user']) && !empty($_POST['pass'])) {  
                $user=$_POST['user'];  
                $pass=$_POST['pass'];  

                $con=mysql_connect('localhost','root','') or die(mysql_error());  
                mysql_select_db('user_registration') or die("cannot select DB");  

                $query=mysql_query("SELECT * FROM User WHERE user_id='".$user."' AND password='".$pass."'");  
                $numrows=mysql_num_rows($query);  
                if($numrows!=0)  
                {  
                while($row=mysql_fetch_assoc($query))  
                {  
                $dbusername=$row['user_id'];  
                $dbpassword=$row['password'];  
                }  

                if($user == $dbusername && $pass == $dbpassword)  
                {  
                session_start();  
                $_SESSION['sess_user']=$user;  

                /* Redirect browser */  
                header("Location: MLS/Data%20Entry/index.php");  
                }  
                } else {  
                echo "Invalid username or password!";  
                }  

            } else {  
                echo "All fields are required!";  
            }  
            }
    ?>
       
        
    <script type="text/javascript">
            document.getElementById("register").onclick = function () {
                location.href="index.html";
            };
        
        
    </script>
        
    </body>
</html>